import requests
import lxml.html as lh
import pandas as pd

from tkinter import *
root=Tk()
root.title('Thời khoá biểu')
root.resizable(False, False)

url='http://thpt-huynhmandat-kiengiang.edu.vn/TKB/tkb_class_14_0.html'
#request
page = requests.get(url)
#Download
doc = lh.fromstring(page.content)
#getAllDataOfPage



tr_elements = doc.xpath('//tr')

#FILE WRITE





#READ
TKB = open("./tkb.va", "r", encoding='utf-8')

Data=TKB.read();

###########FORM###############

logo = PhotoImage(file="avatar.png")
Title=Label(root,text="TKB HMD",font=("Arial Bold", 48),fg='purple')
Title.grid(row=0,column=0,columnspan=5,padx=10,pady=3,sticky="wesn")
TT=Label(root,text="- Anh Nguyen -",font=("Arial Bold", 36),fg='blue')
TT.grid(row=1,column=0,columnspan=5,padx=10,pady=3,sticky="wesn")
w1 = Label(root, image=logo).grid(row=0,rowspan=2,column=5,columnspan=2,padx=10,pady=3)

for col in range(0,6):
    label=Label(text='Thứ {0}'.format(col+2),font=("Arial", 20),fg='green',bg='pink')
    label.grid(row=3,padx=5,pady=3,column=col+1,sticky="wesn");

NM=str(Data).split("\n")


for ro in range(4,9):
    for col in range(0,8):
        if (col==0 or col==1):
            continue
        llabel=Label(text=NM[col+(ro-4)*7-1].split(),font=("Arial", 12),bg='azure')
        llabel.grid(row=ro,padx=5,pady=3,column=col-1,sticky="wesn");

TKB.close()



#WRITE
def writeFile():
    #READ

    TKB = open("./tkb.va", "w", encoding='utf-8')
    for t in range(1,6):
        DATA=str(tr_elements[t].text_content())
        TKB.write(DATA.strip())
        TKB.write("\n")
    TKB.close()


    TKB = open("./tkb.va", "r", encoding='utf-8')

    Data=TKB.read();    
    for col in range(0,6):
        label=Label(text='Thứ {0}'.format(col+2),font=("Arial", 20),fg='green',bg='pink')
        label.grid(row=3,padx=5,pady=3,column=col+1,sticky="wesn");

    NM=str(Data).split("\n")


    for ro in range(4,9):
        for col in range(0,8):
            if (col==0 or col==1):
                continue
            llabel=Label(text=NM[col+(ro-4)*7-1].split(),font=("Arial", 12),bg='azure')
            llabel.grid(row=ro,padx=5,pady=3,column=col-1,sticky="wesn");
    TKB.close()


refresh = Button(root, text ="Refresh", command = writeFile)
refresh.grid(row=10,column=6,pady=10,padx=10);

root.mainloop()

